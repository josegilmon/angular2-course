import { AnimalService } from './services/animal.service';
import { Animal } from './models/animal.model';

import { Component, OnInit, OnDestroy } from '@angular/core';
import { Response } from '@angular/http';
import { Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy{
  animals: Animal[]
  animalsSubscription: Subscription
  animalEdit: Animal

  constructor(private animalService: AnimalService){
  }

  ngOnInit(){
    this.updateAnimals();
  }

  ngOnDestroy(){
    if (this.animalsSubscription){
      this.animalsSubscription.unsubscribe();
    }
  }

  updateAnimals(){
    this.animalEdit = null;
    this.ngOnDestroy();
    this.animalsSubscription = this.animalService.getAll().subscribe(data => this.animals = data);    
  }

  onDelete(animal: Animal){
    this.animalService.delete(animal.id).subscribe(() => this.updateAnimals(), () => {
      alert('Error removing animal');
      this.updateAnimals();
    });
    
  }

  onEdit(animal: Animal){
    this.animalEdit = animal;
  }

  onError(){   
      alert('Error removing animal');
      this.updateAnimals();
  }

  onSave(animal: any) {
    if (animal.bornDate) {
      animal.bornDate = new Date(animal.bornDate.year, animal.bornDate.month-1, animal.bornDate.day);
    }
    if (this.animalEdit) {
      this.animalService.update(this.animalEdit.id, animal).subscribe(() => this.updateAnimals(), () => this.onError());
    } else {
      this.animalService.create(animal).subscribe(() => this.updateAnimals(), () => this.onError());
    }
    
  }
}
