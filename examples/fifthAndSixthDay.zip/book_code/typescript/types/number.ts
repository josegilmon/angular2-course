let decimal: number = 6; 
let hexadecimal: number = 0xffff;
let binary: number = 0b1111;
let octal: number = 0o777
