import { Observable } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FilmService } from '../../services/film.service'; 

@Component({
  selector: 'create-film',
  templateUrl: './create-film.component.html',
  styleUrls: ['./create-film.component.css']
})
export class CreateFilmComponent implements OnInit {
  
  film: any;

  constructor(private filmService: FilmService, private router: Router, private activatedRoute: ActivatedRoute) {
  }

  ngOnInit(){
      this.activatedRoute.params.map((params) => {
          if (params['id']){
              // (+) convierte el string 'id' a numero
              return this.filmService.getFilm(+params['id']);
          }
          return  Observable.of({});
      }).switch().subscribe((film) => this.film = film, (error) => alert('Error al obtener los datos'));
  }


  onSave(film){
      let observable:Observable<any> = null;
      if (this.film && this.film.id){
          //edit
          observable = this.filmService.update(this.film.id, film);
      } else {
          //create          
          observable = this.filmService.addFilm(film);
      }
      observable.subscribe(() => this.router.navigate(['/film']), (error) => alert('Error al guardar los datos'));
      
  }
 
}
