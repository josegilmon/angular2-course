import { ExampleExport, myConst } from '../export/normalExport';

new ExampleExport();

import * as normalExport from "../export/normalExport";
new normalExport.ExampleExport();