import { Animal } from './../../models/animal.model';
import { Component, Input, EventEmitter, Output } from '@angular/core';
@Component({
    selector: 'animal',
    templateUrl: './animal.component.html',
    styleUrls:['./animal.component.css']
})
export class AnimalComponent {
   @Input() data: Animal;
   @Output() onDelete: EventEmitter<Animal> = new EventEmitter()
   @Output() onEdit: EventEmitter<Animal> = new EventEmitter();

   formatDate: string = 'dd/MM/yyyy HH:mm:ss ms'

   delete(event: Event) {
       event.preventDefault();
       this.onDelete.emit(this.data);
   }
   
   edit(event: Event){
       event.preventDefault();
       this.onEdit.emit(this.data);
   }
}