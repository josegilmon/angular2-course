export class ExampleExport {

}
export const myConst = 2;
