import { AnimalFormReactiveComponent } from './shared/animal-form-reactive/animal-form-reactive.component';
import { PurePipe } from './shared/pure.pipe';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { AnimalComponent } from './shared/animal/animal.component';

import { HighLightDirective } from './shared/highlight.directive';
import { LimitTextPipe } from './shared/limitText.pipe';

import { AnimalFormComponent } from './shared/animal-form/animal-form.component';

import { AnimalService } from './services/animal.service';

import { API_URL_OPAQUE } from './config';

@NgModule({
  declarations: [
    AppComponent,
    AnimalComponent,
    HighLightDirective,
    LimitTextPipe,
    PurePipe,
    AnimalFormComponent,
    AnimalFormReactiveComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    NgbModule.forRoot()
  ],
  providers: [
    AnimalService,
    { provide: API_URL_OPAQUE, useValue: 'http://localhost:3000/api' }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
