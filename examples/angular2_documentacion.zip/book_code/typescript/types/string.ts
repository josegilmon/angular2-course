let myVar: string = "Pepe";
myVar = 'Juan';
