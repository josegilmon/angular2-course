import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; //<- Importamos ReactiveFormsModule
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';

import 'rxjs/Rx';

import { AppComponent } from './app.component';
import { FilmComponent } from './shared/film.component'; // <-- Importamos el componente
import { CapitalizeFirstPipe } from './shared/capitalize-first.pipe'; // <-- Importamos el pipe
import { MyShadowDirective } from './shared/myShadow.directive'; // <-- Importamos la directiva
import { FilmFormComponent } from './shared/film-form/film-form.component';
import { FilmFormReactiveComponent } from './shared/film-form-reactive/film-form-reactive.component';

import { FilmService } from './services/film.service';

import { API_CONFIG, value } from './config';

import { CreateFilmComponent } from './pages/create-film/create-film.component';
import { ListFilmComponent } from './pages/list-film/list-film.component';

import { PageNotFoundComponent } from './pages/page-not-found.component';

import { ActivateGuard } from './services/can-activate.service';

import { SureExitGuard } from './services/sure-exit.service';

const appRoutes: Routes = [
  { path: 'film', component: ListFilmComponent, canActivate: [ActivateGuard] },
  { path: 'create', component: CreateFilmComponent, canActivate: [ActivateGuard], canDeactivate: [SureExitGuard] },
  { path: 'edit/:id',      component: CreateFilmComponent, canActivate: [ActivateGuard], canDeactivate: [SureExitGuard] },
  { path: '',
    redirectTo: '/film',
    pathMatch: 'full'
  },
  { path: '**', component: PageNotFoundComponent, canActivate: [ActivateGuard] }
];

/*
 * NGRX
 */
import { StoreModule } from '@ngrx/store';
import { RouterStoreModule } from '@ngrx/router-store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { reducer } from './reducers';
import { FilmAction } from './actions/film.action';
import { FilmSelector } from './selectors/film.selector';


@NgModule({
  declarations: [
    AppComponent,
    FilmComponent,
    CapitalizeFirstPipe,
    MyShadowDirective,
    FilmFormComponent,
    FilmFormReactiveComponent,
    ListFilmComponent,
    CreateFilmComponent,
    PageNotFoundComponent 
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule, // <-- Importamos el modulo http
    ReactiveFormsModule, 
    RouterModule.forRoot(appRoutes),
    StoreModule.provideStore(reducer),
    RouterStoreModule.connectRouter(),
    StoreDevtoolsModule.instrumentOnlyWithExtension(), // importamos este módulo para utilizar la extensión
  ],
  providers: [
    FilmService, 
    ActivateGuard,
    SureExitGuard,
    { provide: API_CONFIG, useValue: value },
    FilmAction,
    FilmSelector
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
