export class renameExport {

}

export {renameExport as RE}