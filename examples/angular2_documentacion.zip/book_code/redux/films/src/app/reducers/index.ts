// Este es el tipo que se genera de la combinación de los reducers
import { ActionReducer } from '@ngrx/store';
// Este es el reducer que se encarga de la gestión del router
import { routerReducer } from '@ngrx/router-store';
// Esta función compone en una función varios middlewares
import { compose } from '@ngrx/core/compose';
// Esta libreria se encarga de chequear que no mutamos el estado
import { storeFreeze } from 'ngrx-store-freeze';
// Esta función combina todos los reducers en uno solo
import { combineReducers } from '@ngrx/store';
// Importamos todo lo que exporta Film.reducer que es la definición del subestado y la función reducer
import * as film from './film.reducer';

export interface State {
    film: film.State
}

const reducers = {
    router: routerReducer,
    film: film.reducer
};

const developmentReducer: ActionReducer<State> = compose(storeFreeze, combineReducers)(reducers);

// Este reducer se utiliza para entornos de producción. Porque no necesitamos la libreria storeFreeze para producción
// const productionReducer: ActionReducer<State> = combineReducers(reducers);

export function reducer(state: any, action: any) {
    return developmentReducer(state, action);
}