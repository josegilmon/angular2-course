let list: number[] = [1, 2, 3]
let listWithGeneric: Array<number> = [1, 2, 3]
