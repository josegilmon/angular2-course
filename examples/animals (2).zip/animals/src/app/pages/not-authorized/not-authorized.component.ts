import { Component } from '@angular/core';

@Component({
    selector: 'not-authorized',
    template: `
        <h2>Not authorized</h2>
        <a routerLink="animal">Back</a>
    `,
    styles: [`
        h2 {
            color: #f00;
        }
    `]
})
export class NotAuthorizedComponent {

}