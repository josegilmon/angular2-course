import { Component } from '@angular/core';
import { FilmService } from '../../services/film.service'; // <- importamos el servicio
import { Observable } from 'rxjs'

@Component({
  selector: 'list-film',
  templateUrl: './list-film.component.html',
  styleUrls: ['./list-film.component.css']
})
export class ListFilmComponent {
  
  films: Observable<any[]>

  constructor(private filmService: FilmService) { //<- Inyectamos la instancia del servicio y declaramos el campo privada filmService
    this.films = this.filmService.getFilms();
  }

  remove(film) {
    if (window.confirm(`¿Seguro que quiere borrar la pelicula ${film.name}?`)){
      this.filmService.removeFilm(film).subscribe(() => this.films = this.filmService.getFilms(), (error) => alert('Error al eliminar la pelicula'));
    }
  }
}
