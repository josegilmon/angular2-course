import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; //<- Importamos ReactiveFormsModule
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { FilmComponent } from './shared/film.component'; // <-- Importamos el componente
import { CapitalizeFirstPipe } from './shared/capitalize-first.pipe'; // <-- Importamos el pipe
import { MyShadowDirective } from './shared/myShadow.directive'; // <-- Importamos la directiva
import { FilmFormComponent } from './shared/film-form/film-form.component';
import { FilmFormReactiveComponent } from './shared/film-form-reactive/film-form-reactive.component';

import { FilmService } from './services/film.service';

import { API_CONFIG, value } from './config';

@NgModule({
  declarations: [
    AppComponent,
    FilmComponent,
    CapitalizeFirstPipe,
    MyShadowDirective,
    FilmFormComponent,
    FilmFormReactiveComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule // <- Importamos ReactiveFormsModule
  ],
  providers: [
    FilmService, // <- Registramos nuestro servicio,
    { provide: API_CONFIG, useValue: value } // <- Registramos el valor
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
