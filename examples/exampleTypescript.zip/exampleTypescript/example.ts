import { MP3Player, Status } from './player';


const mp3 = new MP3Player('./mivideo.mp3');
mp3.play();
if (Status.PLAY === mp3.status){
    console.log('Play');
} else {
    console.log('Stop');
}
mp3.stop();