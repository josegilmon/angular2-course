import { API_URL_OPAQUE } from './../config';
import { Animal } from './../models/animal.model';
import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs';

@Injectable()
export class AnimalService {
    private lastId: number = 3;

    constructor(@Inject(API_URL_OPAQUE) private apiUrl: string, private http: Http){
    }

    getAll(): Observable<Animal[]>{
        return this.http.get(`${this.apiUrl}/animal`).map((data: Response) => data.json());
    }

    get(id: number): Observable<Animal> {
        return this.http.get(`${this.apiUrl}/animal/${id}`).map((data: Response) => data.json());
    }

    create(animal: Animal){
        return this.http.post(`${this.apiUrl}/animal`, animal);
    }

    update(id: number, animalUpdate: Animal){
        return this.http.put(`${this.apiUrl}/animal/${id}`, animalUpdate);
    }

    delete(id: number){
        return this.http.delete(`${this.apiUrl}/animal/${id}`);
    }

}