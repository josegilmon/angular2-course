export class Film {
    id?: number
    name: string;
    gender: string;
    image: string;
    imdbUrl: string;
}