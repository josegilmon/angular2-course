let myAny: any = 'Pepe';
myAny = 2;
myAny = true;
