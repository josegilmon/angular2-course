import { AuthService } from './../../services/auth.service';
import { Component } from '@angular/core';

@Component({
    selector: 'header-app',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css']
})
export class HeaderComponent {

    constructor(private authService: AuthService) {}

    doUser() {
        this.authService.user.roles = 'USER';
    }
    doAdmin() {
        this.authService.user.roles = 'ADMIN';
    }
};