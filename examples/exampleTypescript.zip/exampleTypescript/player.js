var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
(function (Status) {
    Status[Status["STOP"] = 0] = "STOP";
    Status[Status["PLAY"] = 1] = "PLAY";
})(exports.Status || (exports.Status = {}));
var Status = exports.Status;
;
abstract;
var Player = (function () {
    function Player(path) {
        this._status = Status.STOP;
        this.abstract = decode();
        this.path = path;
    }
    Player.prototype.play = function () {
        this.decode();
        this._status = Status.PLAY;
        console.log('Playing');
    };
    Player.prototype.stop = function () {
        this._status = Status.STOP;
        console.log('Stopping');
    };
    Object.defineProperty(Player.prototype, "status", {
        get: function () {
            return this._status;
        },
        enumerable: true,
        configurable: true
    });
    return Player;
})();
var MP3Player = (function (_super) {
    __extends(MP3Player, _super);
    function MP3Player(path) {
        _super.call(this, path);
    }
    MP3Player.prototype.decode = function () {
        console.log('Decoding mp3');
    };
    return MP3Player;
})(Player);
exports.MP3Player = MP3Player;
var AVIPlayer = (function (_super) {
    __extends(AVIPlayer, _super);
    function AVIPlayer(path) {
        _super.call(this, path);
    }
    AVIPlayer.prototype.decode = function () {
        console.log('Decoding AVI');
    };
    return AVIPlayer;
})(Player);
exports.AVIPlayer = AVIPlayer;
//# sourceMappingURL=player.js.map