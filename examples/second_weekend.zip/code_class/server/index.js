var express = require('express');
var app = express();
var cors = require('cors');
var bodyParser = require('body-parser');

var lastId = 20;
var animals = [{
    "id": 1,
    "name": "Tobby",
    "type": "Dog",
    "bornDate":new Date(),
    "image": "http://www.mundoperro.net/wp-content/uploads/consejos-perro-feliz-verano-400x300.jpg"
}, {
    "id": 2,
    "name": "Unix",
    "age": 36,
    "type": "Dog",
    "bornDate": new Date(),
    "image": "http://www.lavanguardia.com/r/GODO/LV/p3/WebSite/2016/10/05/Recortada/img_c…_imagenes_lv_otras_fuentes_perro_beagle-kyEC--656x344@LaVanguardia-Web.jpg"
}, {
    "id": 3,
    "name": "Juan",
    "age": 18,
    "type": "Snake",
    "bornDate":new Date(),
    "image": "http://www.infoserpientes.com/Imagenes/ataque-de-la-serpiente-marron-oriental.jpg"
}];

for(let i = 4; i < 20; i++) {
    animals.push({
        "id": i,
        "name": "Tobby " + i,
        "type": "Dog",
        "bornDate":new Date(),
        "image": "http://www.mundoperro.net/wp-content/uploads/consejos-perro-feliz-verano-400x300.jpg"
    });
}

app.use(cors());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

app.get('/api/animal', function (req, res) {
    res.json(animals);
});

app.get('/api/animal/:id', function (req, res) {
    var element = animals.find((animal) => animal.id === +req.params.id);
    if (!element) {
        res.status(404).send('Not found');
        return;
    }
    res.json(element);
});

app.post('/api/animal', function (req, res) {
    lastId++;
    var animal = req.body;
    animal.id = lastId;
    animals.push(animal);
    res.json({});
});

app.put('/api/animal/:id', function (req, res) {
    var find = false;
    var animal = req.body;
    animals = animals.map((data) => {
        if (data.id === +req.params.id) {
            find = true;
            data.name = animal.name;
            data.age = animal.age;
            data.type = animal.type;
            data.bornDate = animal.bornDate;
            data.image = animal.image;
        }
        return data;
    });
    if (!find) {
        res.status(404).send('Not found');
        return;
    }
    res.json({});
});

app.delete('/api/animal/:id', function (req, res) {
    var find = false;
    animals = animals.filter((animal) => {
        if (animal.id === +req.params.id) {
            find = true;
        }
        return animal.id !== +req.params.id;
    });
    if (!find) {
        res.status(404).send('Not found');
        return;
    }
    res.json({});
});

app.listen(3000, function () {
    console.log('animals API running in 3000 port!');
});