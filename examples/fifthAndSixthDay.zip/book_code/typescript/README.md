#Typescript
En carpeta tenemos todos los ejemplos en código de la sección Typescript del manual.

##Build
Es necesario tener instalado [NodeJS](https://nodejs.org/es/)

Instalar typescript

````javascript
npm install -g typescript
````

Para compilar cada ejemplo, ejecutar el siguiente comando en cada carpeta:

````javascript
typescript --watch *.ts
````