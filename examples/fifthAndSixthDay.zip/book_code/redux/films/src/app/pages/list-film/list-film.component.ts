import { FilmSelector } from './../../selectors/film.selector';
import { FilmAction } from './../../actions/film.action';
import { Component } from '@angular/core';
import { Observable } from 'rxjs'

@Component({
  selector: 'list-film',
  templateUrl: './list-film.component.html',
  styleUrls: ['./list-film.component.css']
})
export class ListFilmComponent {
  
  films$: Observable<any[]>

  constructor(private filmAction: FilmAction, private filmSelector: FilmSelector) { //<- Inyectamos la instancia del selector y de las acciones
    this.filmAction.getFilms(); // <-- Emitimos la accion de actualizar las peliculas
    this.films$ = this.filmSelector.getFilms(); // <-- Obtenemos el stream que nos dará las peliculas
  }

  remove(film) {
    if (window.confirm(`¿Seguro que quiere borrar la pelicula ${film.name}?`)){
      this.filmAction.deleteFilm(film);
    }
  }
}
