import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module'; // <- Importamos el módulo principal de nuestra aplicacion

platformBrowserDynamic().bootstrapModule(AppModule); // <- Arrancamos la aplicación con ese módulo