class StaticExample {
    static value: number = 2;
}

console.log(StaticExample.value);