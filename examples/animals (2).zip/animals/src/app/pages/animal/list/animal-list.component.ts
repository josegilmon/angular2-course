import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { AnimalService } from './../../../services/animal.service';
import { Subscription } from 'rxjs';
import { Animal } from './../../../models/animal.model';
import { Component, OnDestroy, OnInit } from '@angular/core';
@Component({
    selector: 'animal-list',
    templateUrl: './animal-list.component.html'
})
export class AnimalListComponent implements OnInit, OnDestroy{
    animals: Animal[]
    animalsSubscription: Subscription

    constructor(private animalService: AnimalService, private route: ActivatedRoute, private router: Router) {
    }

    ngOnInit() {
        this.updateAnimals();
    }

    ngOnDestroy() {
        if (this.animalsSubscription) {
            this.animalsSubscription.unsubscribe();
        }
    }

    updateAnimals() {
        this.ngOnDestroy();
        this.animalsSubscription = this.animalService.getAll().subscribe(data => this.animals = data);
    }

    onDelete(animal: Animal) {
        this.animalService.delete(animal.id).subscribe(() => this.updateAnimals(), () => {
            alert('Error removing animal');
            this.updateAnimals();
        });

    }

    onEdit(animal: Animal) {        
        this.router.navigate(['../edit', animal.id], { relativeTo: this.route } );
    }

    onError() {
        alert('Error removing animal');
        this.updateAnimals();
    }
}