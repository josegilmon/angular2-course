# My first app angular2

## Install
Install packages
````
npm install
````

## Run
Execute
````
npm start
````

and open [http://localhost:8080](http://localhost:8080)