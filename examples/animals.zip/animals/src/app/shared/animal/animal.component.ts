import { Animal } from './../../models/animal.model';
import { Component, Input, EventEmitter, Output } from '@angular/core';
@Component({
    selector: 'animal',
    templateUrl: './animal.component.html',
    styleUrls:['./animal.component.css']
})
export class AnimalComponent {
   @Input() data: Animal;
   @Output() onDelete:EventEmitter<Animal> = new EventEmitter()

   delete(event: Event) {
       event.preventDefault();
       this.onDelete.emit(this.data);
   }
}