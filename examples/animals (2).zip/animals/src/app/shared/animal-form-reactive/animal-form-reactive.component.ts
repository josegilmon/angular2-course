import { Animal } from './../../models/animal.model';
import { Component, OnInit, EventEmitter, Output, Input, OnChanges, SimpleChanges } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

@Component({
    selector:'animal-form-reactive',
    templateUrl: './animal-form-reactive.component.html',
    styles: [`
        form {
            width: 80%;
            display: block;
            margin: 0 auto;
        }
    `]
})
export class AnimalFormReactiveComponent implements OnInit, OnChanges {

    types: string[] = ['Dog', 'Cat', 'Snake'];
    animal: Animal

    form: FormGroup
    @Input() data: Animal;
    @Output() onSave: EventEmitter<Animal> = new EventEmitter();

    constructor(private formBuilder: FormBuilder) {
        
    }

    save(value: Animal){
        this.onSave.emit(value);
        this.form.reset();
    }

    initForm(){
        let date = {};
        if (this.data && this.data.bornDate){
            this.data.bornDate = new Date(this.data.bornDate);
            date = {
                year: this.data.bornDate.getFullYear(),
                month: this.data.bornDate.getMonth() + 1,
                day: this.data.bornDate.getDate()
            };
        } 
        this.form = this.formBuilder.group({
            name: [this.data ? this.data.name : '', [Validators.required, Validators.minLength(5)]],
            type: [this.data ? this.data.type : '', Validators.required],
            image: [this.data ? this.data.image : '', Validators.required],
            bornDate: [date]
        });
    }

    ngOnChanges(changes: SimpleChanges){
        this.initForm();
    }

    ngOnInit(){
        this.initForm();
    }
}