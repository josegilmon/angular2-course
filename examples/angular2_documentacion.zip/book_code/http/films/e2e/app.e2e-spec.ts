import { SeasonsPage } from './app.po';

describe('seasons App', function() {
  let page: SeasonsPage;

  beforeEach(() => {
    page = new SeasonsPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
