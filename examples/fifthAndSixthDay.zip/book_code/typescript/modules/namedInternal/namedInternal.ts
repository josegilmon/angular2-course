module Vehicles {
    class Car {

    }
    class Truck {

    }
    var myCar = new Car();
}

