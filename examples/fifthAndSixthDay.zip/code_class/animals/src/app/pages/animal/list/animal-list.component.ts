import { State } from './../../../reducers/index';
import { AnimalAction } from './../../../actions/animal.action';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { AnimalService } from './../../../services/animal.service';
import { Subscription, Observable } from 'rxjs';
import { Animal } from './../../../models/animal.model';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';

@Component({
    selector: 'animal-list',
    templateUrl: './animal-list.component.html'
})
export class AnimalListComponent implements OnInit, OnDestroy{
    animals: Animal[]
    animalsSubscription: Subscription
    animals$: Observable<Animal[]>

    constructor(private animalAction: AnimalAction, private store: Store<State>,  private route: ActivatedRoute, private router: Router) {
    }

    ngOnInit() {
        this.animalAction.getAnimals();
        this.animals$ = this.store.select((state: State) => state.animals.entities);
    }

    ngOnDestroy() {
        if (this.animalsSubscription) {
            this.animalsSubscription.unsubscribe();
        }
    }

    onDelete(animal: Animal) {
        // this.animalService.delete(animal.id).subscribe(() => this.updateAnimals(), () => {
        //     alert('Error removing animal');
        //     this.updateAnimals();
        // });

    }

    onEdit(animal: Animal) {        
        this.router.navigate(['../edit', animal.id], { relativeTo: this.route } );
    }

    onError() {
        // alert('Error removing animal');
        // this.updateAnimals();
    }
}