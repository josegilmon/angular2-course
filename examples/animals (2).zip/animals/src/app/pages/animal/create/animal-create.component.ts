import { Observable, Subscription } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { AnimalService } from './../../../services/animal.service';
import { Animal } from './../../../models/animal.model';
import { Component, OnInit, OnDestroy } from '@angular/core';
@Component({
  selector: 'animal-create',
  templateUrl: './animal-create.component.html'
})
export class AnimalCreateComponent implements OnInit, OnDestroy {
  animalEdit: Animal
  animalSubs: Subscription;
  allowExit: boolean = false;

  constructor(private animalService: AnimalService, private router: Router, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.animalSubs = this.route.params.map((params: any) => {
      if (params && params.id) {
        return this.animalService.get(+params.id);
      }
      return Observable.of(null);
    }).switch().subscribe((obj) => {
      this.animalEdit = obj;
    });
  }

  ngOnDestroy() {
    if (this.animalSubs) {
      this.animalSubs.unsubscribe();
    }
  }

  onError() {
    alert('Error removing animal');
  }

  back() {
    this.allowExit = true;
    this.router.navigate(['./list']);
  }

  onSave(animal: any) {
    if (animal.bornDate) {
      animal.bornDate = new Date(animal.bornDate.year, animal.bornDate.month - 1, animal.bornDate.day);
    }
    if (this.animalEdit) {
      this.animalService.update(this.animalEdit.id, animal).subscribe(() => this.back(), () => this.onError());
    } else {
      this.animalService.create(animal).subscribe(() => this.back(), () => this.onError());
    }

  }
}