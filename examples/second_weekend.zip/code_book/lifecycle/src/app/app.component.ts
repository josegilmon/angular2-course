import { Component, OnInit, OnDestroy, OnChanges, DoCheck, 
  AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, SimpleChanges, Input } from '@angular/core';




@Component({
  selector: 'counter',
  template: `
  <h1> Counter {{count}}</h1>
  `,
  styles: []
})
export class CounterComponent implements OnChanges, OnInit, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {
  @Input() count
  ngOnChanges(changes: SimpleChanges) {
    console.log('Counter ngOnChange', changes);
  }

  ngOnInit(){ 
    console.log('Counter onInit');
  }

  ngDoCheck() {
    console.log('Counter DoCheck')
  }

  ngAfterContentInit() {
    console.log('Counter AfterContentInit');
  }

  ngAfterContentChecked() {
    console.log('Counter AfterContentChecked');
  }

  ngAfterViewInit() {
    console.log('Counter AfterViewInit');
  }

  ngAfterViewChecked() {
    console.log('Counter AfterViewChecked');
  }

  ngOnDestroy() {
    console.log('Counter onDestroy');
  }
}

@Component({
  selector: 'app-root',
  template: `
  
  <counter [count]="num" *ngIf="showCounter"></counter>
  <button (click)="showCounter=!showCounter">Toggle counter</button>
  <button (click)="increment()">Increment counter</button>
  `,
  styles: []
})
export class AppComponent{
  num: number = 0
  showCounter: boolean = true
  
  increment() {
    this.num++;
  }
}
