import { Injectable, Inject } from '@angular/core';
import { Http } from '@angular/http';
import { API_CONFIG } from './../config'; 

@Injectable()
export class FilmService {


    constructor(@Inject(API_CONFIG) private apiConfig: any, private http: Http) {
    }

    getFilms(){
        let url = `${this.apiConfig.url}${this.apiConfig.path}/film`;    
        return this.http.get(url).map(res => res.json() || []);
    }

    removeFilm(film) {
        let url = `${this.apiConfig.url}${this.apiConfig.path}/film/${film.id}`;    
        return this.http.delete(url).map(res => res.json() || []);
    }

    addFilm(film) {
        let url = `${this.apiConfig.url}${this.apiConfig.path}/film`;    
        return this.http.post(url, film).map(res => res.json() || []);
    }

    getFilm(id) {
        let url = `${this.apiConfig.url}${this.apiConfig.path}/film/${id}`;    
        return this.http.get(url).map(res => res.json() || []);
    }

    update(id, film){
        let url = `${this.apiConfig.url}${this.apiConfig.path}/film/${id}`;    
        return this.http.patch(url, film).map(res => res.json() || []);
    }
}