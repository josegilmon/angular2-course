for (let i = 0; i < 10; i++){
    console.log(i);
}
console.log(i); //ERROR: i no existe en este scope porque solo existe en el scope del for
