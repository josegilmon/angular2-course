import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { FilmComponent } from './shared/film.component'; // <-- Importamos el componente
import { CapitalizeFirstPipe } from './shared/capitalize-first.pipe'; // <-- Importamos el pipe
import { MyShadowDirective } from './shared/myShadow.directive'; // <-- Importamos la directiva

import { FilmService } from './services/film.service';

import { API_CONFIG, value } from './config';

@NgModule({
  declarations: [
    AppComponent,
    FilmComponent,
    CapitalizeFirstPipe,
    MyShadowDirective 
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [
    FilmService, // <- Registramos nuestro servicio,
    { provide: API_CONFIG, useValue: value } // <- Registramos el valor
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
