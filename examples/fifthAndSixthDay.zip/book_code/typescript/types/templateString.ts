let person = 'Juan';
let text = `Hello, my name is ${person}`;
console.log(text);
