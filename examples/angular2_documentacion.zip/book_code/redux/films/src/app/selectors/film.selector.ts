import { Film } from './../models/film.model';
import { Store } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { State } from '../reducers';
import { State as FilmState } from '../reducers/film.reducer';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class FilmSelector {

  constructor(private store: Store<State>){}

  getFilms(): Observable<Film[]> {
    return this.store.select( state => state.film.entities);
  }

  getFilm(): Observable<Film> {
    return this.store.select( state => state.film.film);
  }

}