import { Component } from '@angular/core';

@Component({
    selector: 'animal-root',
    template: `
        <h1> Animals page</h1>
        <router-outlet></router-outlet>
    `
})
export class AnimalRootComponent {

}