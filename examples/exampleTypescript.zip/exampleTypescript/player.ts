export enum Status{STOP, PLAY};

abstract class Player {
    private _status: Status = Status.STOP;
    path: string;

    constructor(path: string) {
        this.path = path;
    }

    play():void {
        this.decode();
        this._status = Status.PLAY;
        console.log('Playing');
    }

    stop():void {
        this._status = Status.STOP;
        console.log('Stopping');
    }

    get status():Status {
        return this._status;
    }

    abstract decode():void;

}

export class MP3Player extends Player {
    constructor(path){
        super(path);
    }

    decode():void {
        console.log('Decoding mp3');
    }
}


export class AVIPlayer extends Player {
    constructor(path){
        super(path);
    }

    decode():void {
        console.log('Decoding AVI');
    }
}

