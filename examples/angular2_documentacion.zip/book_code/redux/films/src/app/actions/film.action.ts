import { FilmService } from './../services/film.service';
import { Injectable } from '@angular/core';
import { Action, Store } from '@ngrx/store';
import { State } from '../reducers';

// definimos un enumerado con todas las posibles acciones que puede recibir el reducer
export enum FilmActions {
  FILM_SEARCH,
  GET_FILM
};


export class SearchAction implements Action {
  type = FilmActions[FilmActions.FILM_SEARCH];

  constructor(public payload: any) { }
}

export class GetAction implements Action {
  type = FilmActions[FilmActions.GET_FILM];

  constructor(public payload: any) { }
}

// exportamos las posibles acciones que tenemos en un objeto Actions.
export type Actions = SearchAction | GetAction;


@Injectable()
export class FilmAction {

  constructor(private filmService: FilmService, private store: Store<State>){}

  getFilms(){
    this.filmService.getFilms().subscribe(data => {
      this.store.dispatch(new SearchAction(data));
    }, () => console.error('Error obtaining Films'));
  }

  getFilm(id){
    this.filmService.getFilm(id).subscribe(data => {
      this.store.dispatch(new GetAction(data));
    }, () => console.error('Error obtaining Films'));
  }

  deleteFilm(id){
    this.filmService.removeFilm(id).subscribe(data => {
      this.getFilms();
    }, () => console.error('Error deleting Film'));
  }

  createFilm(film){
    this.filmService.addFilm(film).subscribe(data => {
      this.getFilms();
    }, () => console.error('Error creating Film'));
  }

  updateFilm(id, film){
    this.filmService.update(id, film).subscribe(data => {
      this.getFilms();
    }, () => console.error('Error updating Film'));
  }
}