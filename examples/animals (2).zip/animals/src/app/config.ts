import { OpaqueToken } from '@angular/core';

const API_URL = 'API_URL';

export const API_URL_OPAQUE = new OpaqueToken(API_URL);
