import { FilmAction } from './../../actions/film.action';
import { FilmSelector } from './../../selectors/film.selector';
import { Observable, Subscription } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FilmService } from '../../services/film.service'; 

@Component({
  selector: 'create-film',
  templateUrl: './create-film.component.html',
  styleUrls: ['./create-film.component.css']
})
export class CreateFilmComponent implements OnInit, OnDestroy {
  
  film: any;
  filmSubs: Subscription

  constructor(private filmAction: FilmAction, private filmSelector: FilmSelector, private router: Router, private activatedRoute: ActivatedRoute) {
  }

  ngOnInit(){
      this.filmSubs = this.filmSelector.getFilm().subscribe(data => this.film = data);
      this.activatedRoute.params.subscribe((params) => {
          if (params['id']){
              // (+) convierte el string 'id' a numero
              this.filmAction.getFilm(+params['id']);
          }          
      });
  }

  ngOnDestroy() {
      this.filmSubs.unsubscribe();
  }


  onSave(film){
      if (this.film && this.film.id){
          //edit
          this.filmAction.updateFilm(this.film.id, film);
      } else {
          //create          
          this.filmAction.createFilm(film);
      }
      this.router.navigate(['/film']);      
  }
 
}
