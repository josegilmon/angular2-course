import { Animal } from './../../models/animal.model';
import { Component } from '@angular/core';

@Component({
    selector:'animal-form',
    templateUrl: './animal-form.component.html',
    styles: [`
        form {
            width: 80%;
            display: block;
            margin: 0 auto;
        }
    `]
})
export class AnimalFormComponent{

    types: string[] = ['Dog', 'Cat', 'Snake'];
    animal: Animal

    constructor() {
        
    }
    show(text) {
        console.log(text);
    }

    save(value: Animal){
        console.log(value);
    }
}