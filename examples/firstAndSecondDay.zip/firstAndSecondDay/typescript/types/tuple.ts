let myTuple: [number, string];

myTuple = [1, 'hello']; //OK
myTuple = ['hello', 1]; //ERROR
