import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
    name: 'limitText',
    pure: true
})
export class LimitTextPipe implements PipeTransform {
    transform(value: string, numCha = 2 ) {        
        if (value && value.length > numCha) {
            return `${value.substring(0, numCha)}...`;
        }
        return value;
    }
}