class MyClass {
    public myVar:string;
}

let myClass = new MyClass();
