import { Injectable } from '@angular/core';
import { AnimalCreateComponent } from './../pages/animal/create/animal-create.component';

import { CanDeactivate } from '@angular/router';

@Injectable()
export class ExitCanDeactiveGuard implements CanDeactivate<AnimalCreateComponent> {
    
    canDeactivate(instance: AnimalCreateComponent): boolean {
        if (instance.allowExit){
            return true;
        }
        return window.confirm('Are you sure that you want exit?');
    }
}