import { Injectable } from '@angular/core';

@Injectable()
export class AuthService {
    user: any = {
        name: 'pepe',
        roles: 'ADMIN'
    };
}