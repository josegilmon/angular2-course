function sayHello():void {
	alert('hello');
}

sayHello();
