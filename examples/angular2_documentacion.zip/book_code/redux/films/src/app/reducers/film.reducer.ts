import { Film } from './../models/film.model';
import * as film from '../actions/film.action';

// Definimos el tipo del subestado Film. 
export interface State {
  entities: Film[],
  film: Film
};

// declaramos un estado inicial
const initialState: State = {
  entities: [],
  film: null
};

export function reducer(state = initialState, action: film.Actions): State {
  switch (action.type) {
    case film.FilmActions[film.FilmActions.FILM_SEARCH]:
      return {
        entities: action.payload,
        film: null
      }
    case film.FilmActions[film.FilmActions.GET_FILM]:
      return Object.assign({}, state, {
        film: action.payload
      });
    default:
      return state;
  }
}