export class Animal {
    name: string;
    age: number;
    type: string;
    bornDate: Date;
    image: string;

    constructor(name: string, age: number, type: string, bornDate: Date, image: string = 'http://www.todoperros.com/wp-content/uploads/2016/08/perro.jpg') {
        this.name = name;
        this.age = age;
        this.type = type;
        this.bornDate = bornDate;
        this.image = image;
    }
}