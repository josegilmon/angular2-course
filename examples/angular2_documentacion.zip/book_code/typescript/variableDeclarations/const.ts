const names:string[] = [];
names.push("Jordan");
console.log(names);

names = []; //ERROR: names es una constante y no puede cambiarse

