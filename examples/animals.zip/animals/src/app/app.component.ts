import { Animal } from './models/animal.model';

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  animals: Animal[] = [new Animal('Tobby', undefined, 'Dog', new Date(), 'http://www.mundoperro.net/wp-content/uploads/consejos-perro-feliz-verano-400x300.jpg'), 
  new Animal('Unix', 36, 'Dog', new Date(), 'http://www.lavanguardia.com/r/GODO/LV/p3/WebSite/2016/10/05/Recortada/img_cvillalonga_20161005-162327_imagenes_lv_otras_fuentes_perro_beagle-kyEC--656x344@LaVanguardia-Web.jpg'), 
  new Animal('Juan', 18, 'Snake', new Date(), 'http://www.infoserpientes.com/Imagenes/ataque-de-la-serpiente-marron-oriental.jpg')]

  onDelete(animal: Animal){
    console.log('Delete ', animal);
  }
}
