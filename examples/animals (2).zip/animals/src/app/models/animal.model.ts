export class Animal {
    id?: number
    name: string;
    age: number;
    type: string;
    bornDate: Date;
    image: string;

    constructor(id: number, name: string, age: number, type: string, bornDate: Date, image: string = 'http://www.todoperros.com/wp-content/uploads/2016/08/perro.jpg') {
        this.id = id;
        this.name = name;
        this.age = age;
        this.type = type;
        this.bornDate = bornDate;
        this.image = image;
    }
}