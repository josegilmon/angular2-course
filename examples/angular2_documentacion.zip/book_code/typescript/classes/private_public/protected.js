var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var Vehicle = (function () {
    function Vehicle(type) {
        this.type = type;
    }
    Vehicle.prototype.start = function () {
        if (this.type === 'diesel') {
            console.log('brummm');
        }
    };
    return Vehicle;
})();
var DieselCar = (function (_super) {
    __extends(DieselCar, _super);
    function DieselCar() {
        _super.call(this, 'diesel');
    }
    DieselCar.prototype.startEngine = function () {
        this.start();
    };
    return DieselCar;
})(Vehicle);
var myCar = new DieselCar();
myCar.start(); // ERROR. El metodo es protected
myCar.startEngine();
