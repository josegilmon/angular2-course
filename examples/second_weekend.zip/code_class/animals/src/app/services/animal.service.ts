import { API_URL_OPAQUE } from './../config';
import { Animal } from './../models/animal.model';
import { Injectable, Inject } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs';

@Injectable()
export class AnimalService {
    private lastId: number = 3;

    animals: Animal[] = [new Animal(1, 'Tobby', undefined, 'Dog', new Date(), 'http://www.mundoperro.net/wp-content/uploads/consejos-perro-feliz-verano-400x300.jpg'),
    new Animal(2, 'Unix', 36, 'Dog', new Date(), 'http://www.lavanguardia.com/r/GODO/LV/p3/WebSite/2016/10/05/Recortada/img_cvillalonga_20161005-162327_imagenes_lv_otras_fuentes_perro_beagle-kyEC--656x344@LaVanguardia-Web.jpg'),
    new Animal(3, 'Juan', 18, 'Snake', new Date(), 'http://www.infoserpientes.com/Imagenes/ataque-de-la-serpiente-marron-oriental.jpg')]

    constructor(@Inject(API_URL_OPAQUE) private apiUrl: string, private http: Http){
    }

    getAll(): Observable<Animal[]>{
        return this.http.get(`${this.apiUrl}/animal`).map((data: Response) => data.json());
    }

    get(id: number){
        return this.animals.find((animal) => animal.id === id);
    }

    create(animal: Animal){
        return this.http.post(`${this.apiUrl}/animal`, animal);
    }

    update(id: number, animalUpdate: Animal){
        return this.http.put(`${this.apiUrl}/animal/${id}`, animalUpdate);
    }

    delete(id: number){
        return this.http.delete(`${this.apiUrl}/animal/${id}`);
    }

}