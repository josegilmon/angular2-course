import { AnimalAction } from './actions/animal.action';
import { AnimalRootComponent } from './pages/animal/animal-root.component';
import { ExitCanDeactiveGuard } from './guards/exit.guard';
import { NotAuthorizedComponent } from './pages/not-authorized/not-authorized.component';
import { AuthGuard } from './guards/auth.guard';
import { AuthService } from './services/auth.service';
import { AnimalListComponent } from './pages/animal/list/animal-list.component';
import { AnimalCreateComponent } from './pages/animal/create/animal-create.component';
import { AnimalFormReactiveComponent } from './shared/animal-form-reactive/animal-form-reactive.component';
import { PurePipe } from './shared/pure.pipe';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { AnimalComponent } from './shared/animal/animal.component';

import { HighLightDirective } from './shared/highlight.directive';
import { LimitTextPipe } from './shared/limitText.pipe';

import { AnimalFormComponent } from './shared/animal-form/animal-form.component';

import { AnimalService } from './services/animal.service';

import { API_URL_OPAQUE } from './config';

import { HeaderComponent } from './shared/header/header.component';

import { Routes, RouterModule } from '@angular/router';

import { StoreModule } from '@ngrx/store';
import { RouterStoreModule } from '@ngrx/router-store';
import { reducer } from './reducers';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

const childrenAnimal: Routes = [{
  path: '', redirectTo: 'list', pathMatch: 'full'
}, {
  path: 'list', component: AnimalListComponent
}, {
  path: 'create', component: AnimalCreateComponent,  canDeactivate: [ExitCanDeactiveGuard]
}, {
  path: 'edit/:id', component: AnimalCreateComponent, canDeactivate: [ExitCanDeactiveGuard]
}];

const routes: Routes = [{
  path: '', redirectTo: 'animal/list', pathMatch: 'full'
},{
  path: 'animal', component: AnimalRootComponent, children: childrenAnimal, canActivateChild: [AuthGuard]
}, {
  path: 'not-authorized', component: NotAuthorizedComponent
}, {
  path: '**', redirectTo: 'animal/list'
}];

@NgModule({
  declarations: [
    AppComponent,
    AnimalComponent,
    HighLightDirective,
    LimitTextPipe,
    PurePipe,
    AnimalFormComponent,
    AnimalFormReactiveComponent,
    HeaderComponent,
    AnimalCreateComponent,
    AnimalListComponent,
    NotAuthorizedComponent,
    AnimalRootComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    NgbModule.forRoot(),
    RouterModule.forRoot(routes),
    StoreModule.provideStore(reducer),
    RouterStoreModule.connectRouter(),
    StoreDevtoolsModule.instrumentOnlyWithExtension(),
  ],
  providers: [
    AnimalService,
    AuthService,
    AuthGuard,
    ExitCanDeactiveGuard,
    AnimalAction,
    { provide: API_URL_OPAQUE, useValue: 'http://45.32.235.206:3000/api' }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
