import { State } from './../reducers/index';
import { AnimalService } from './../services/animal.service';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';

@Injectable()
export class AnimalAction {

    constructor(private animalService: AnimalService, private store: Store<State>) { }

    getAnimals() {
        this.animalService.getAll().subscribe((animals) => {
            this.store.dispatch({ type: 'SEARCH_ANIMALS', payload: animals })
        })
    }
}