#API Server

## Install
Execute the next command:

```
npm install
```

## Run
Execute the next command:

```
npm start
```
