import { Animal } from './../models/animal.model';

import * as animal from './animal.reducer';

import { ActionReducer, combineReducers } from '@ngrx/store';
import { compose } from '@ngrx/core';
import { storeFreeze } from 'ngrx-store-freeze';
import { routerReducer } from '@ngrx/router-store';


export interface State {
    animals: animal.IAnimalState
}

const reducers = {
    animals: animal.reducer,
    router: routerReducer
}

const developmentReducer: ActionReducer<State> = compose(storeFreeze, combineReducers)(reducers);

export function reducer(state: State, action: any){
    return developmentReducer(state, action);
}