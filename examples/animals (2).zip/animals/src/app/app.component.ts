import { AnimalService } from './services/animal.service';
import { Animal } from './models/animal.model';

import { Component, OnInit, OnDestroy } from '@angular/core';
import { Response } from '@angular/http';
import { Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
}
