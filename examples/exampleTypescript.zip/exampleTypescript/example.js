var player_1 = require('./player');
var mp3 = new player_1.MP3Player('./mivideo.mp3');
mp3.play();
if (player_1.Status.PLAY === mp3.status) {
    console.log('Play');
}
else {
    console.log('Stop');
}
mp3.stop();
//# sourceMappingURL=example.js.map