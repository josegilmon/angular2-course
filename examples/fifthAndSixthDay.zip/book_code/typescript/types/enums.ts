enum Animals {Dog, Snake, Cat};
let a: Animals = Animals.Dog;
